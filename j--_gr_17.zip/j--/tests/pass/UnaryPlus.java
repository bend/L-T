
package pass;

import java.lang.System;

public class UnaryPlus {

    public int unaryPlus(int x) {
        return +x;
    }

}
