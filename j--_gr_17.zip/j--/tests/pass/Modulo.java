
package pass;

import java.lang.System;

public class Modulo {

    public int modulo(int x, int y) {
        return x % y;
    }

}
