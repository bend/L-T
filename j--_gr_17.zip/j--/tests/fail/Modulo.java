package fail;

import java.lang.System;

public class Modulo
{
    public static void main(String[] args)
    {
        System.out.println('a' % 42);
        System.out.println(42 % 'a');
        System.out.println(42 % 0);
    }
}
